# ROOT FF 进程 owner 收敛实施细则

2026-10-16。这是 ROOT 接收节点发现的共因修复，不归咎于 DU6 oracle 作者。

## 已有证据

ROOT 集中252项中251 PASS；旧0.2s deadline测试实际5.247s，超过既有<5断言。matrix.runtime重复了Popen、taskkill(5)、communicate(5)、wait(5)；生产 scripts/ff_process_transport 已提供单deadline、Windows先入Job再释放用户代码、统一2.5s cleanup的run_bounded。

## 一次共因改造

- runtime.run_process只做薄adapter：以文件相对路径找到scripts公开transport；先deadline.remaining，不再给case/batch重新起预算；传该remaining、原env/cwd/input。
- 成功dict映射CompletedProcess；ChildFailed保留returncode/stdout/stderr映射原CompletedProcess非0语义；ChildTimeout映射DeadlineExceeded并保留cause；其他异常原样传播，由唯一transport finally回收。
- 删除matrix `_terminate_tree`和重复Popen/communicate/wait。生产transport/tree、业务case30/batch180、cli_main/oracle及作者树均不改。
- 显式沿用生产transport的32MiB stdout/64KiB stderr资源上限，不发明第二套读取/进程预算。

## TDD与验收

1. 新ROOTtests先RED：port实际调用与剩余deadline、过期不spawn、原始成功/非0bytes、ChildTimeout具名映射、真实child+descendant超时回收、无taskkill。
2. 适配一处runtime后跑短责任suite。两条旧测试直接mock communicate/_terminate_tree，与被删除实现耦合，分别迁移到真实public transport的异常 `_await_lifetime` 和 `_IOState.start` 注入；保留/加强实际proc已退出、管道关闭、无线程遗留断言，不降低旧时间断言。
3. 正常host隔离Temp运行新ROOT/runtime/W07/原transport生命周期责任tests，保留首RED、最终结果、源码SHA和清理收据。不并发重跑252，交ROOT统一合流。

所有测试离线、无密钥/供应商调用；只删除验证过的本次Temp。无Git写、安装、推送。
