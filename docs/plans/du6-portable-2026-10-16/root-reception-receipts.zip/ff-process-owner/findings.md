# ROOT：FF 矩阵复用统一进程 owner

2026-10-16。完成，等待 ROOT 统一提交/推送；无 Git 写。

## 根因与改造

ROOT 接收集中测试原记录252中251 PASS/1 FAIL，0.2秒 deadline的旧 <5s 测试实际5.247s。不是 DU6 evidence_root/oracle 作者缺陷。matrix.runtime 另实现 taskkill(5s)、communicate(5s)、wait(5s)，导致业务 deadline过后仍串行等待；项目原有 `scripts/ff_process_transport.py::run_bounded` 已统一了实际生命周期、Windows先入Job再释放用户代码以及一次2.5s cleanup。

本修复删除矩阵 `_terminate_tree` 和重复Popen/communicate/wait，只留薄adapter：先 `deadline.remaining()`，原样传剩余时间/bytes/env/cwd；成功和 ChildFailed映射既有CompletedProcess，保留非0返回码及原始bytes；ChildTimeout映射DeadlineExceeded并保留cause；其他错误不吞掉，由transport自己的finally回收。scripts路径由runtime文件位置计算，不硬编码机器目录。

生产 ff_process_transport/ff_process_tree没有改；case30、batch180、旧0.2s和<5s测试断言没有改。生产transport的既有32MiB stdout/64KiB stderr限制直接复用，没有新增第二套预算或tree杀进程实现。

## 测试迁移理由

仅迁移两条旧mock测试，函数名保留：

- W07 `test_run_process_reaps_child_when_communicate_raises_other_error` 原来fake Popen.communicate及taskkill。现在注入同一个真实public transport的 `_await_lifetime` 异常，实际启动原生child，断言进程已退出、全部管道关闭、reader/writer线程无遗留。
- ROOT W07 `test_dead_child_is_reaped_after_second_communicate_error` 原来mock将删除的 `_terminate_tree`。现在在真实 `_IOState.start` 已启动reader线程后抛错，检查同样实际回收。原“fake.waited”断言由实际退出/管道/线程检查替代，未降低要求。

新增6项ROOT测试：精确传递剩余deadline/bytes/env/cwd；过期不进transport；ChildTimeout映射cause；实际成功/exit7原始bytes；实际child+descendant超时均回收且 `subprocess.run/taskkill` 调用数为0。后者必须实际产生两个PID后检查均已退出，不能以“child未启动”冒认子树覆盖；仅在测试失败时按这两个已记录PID清理。

## 留证结果

- 首RED：2 FAIL/1 PASS/3 deselected，证明未复用公共端口；这是端口RED，不冒认新的经济语义错误。原真实时间RED来自ROOT接收集中收据，完整保留。
- 首GREEN：49 PASS/1 FAIL；失败仅迁移旧测试遗漏函数内os导入，修复后重跑，未动生产期限。
- 矩阵/runtime/W07/ROOT-W07及原transport生命周期责任测试共 **73 PASS /14.17s**，无skip。含原0.2秒/<5秒测试、WindowsJob/bootstrap、生命周期与异常回收。
- 最后加强zero-taskkill显式计数、仅格式化新增ROOT测试后，新6项 **6 PASS /2.38s**。定点Ruff通过。
- 全部使用正常host、独立Temp、PYTHONDONTWRITEBYTECODE，前后源码SHA guard一致、自建Temp清理成功；0网络/API/供应商/密钥读取/生产原件写入。

只冻结4个本线文件：runtime、上述两旧测试、一个新增ROOT测试。集成树中cli_main/replay_output_ownership为ROOT其他工作，本线没有修改，不纳入owned。作者树没有修改。

## 限制

本节点没有重跑252或真实41跨仓矩阵，按ROOT指令避免与RF等大套件并发；交ROOT最终合流节点顺序运行。上述结果证明统一进程生命周期与薄adapter责任，不声称真实供应商采集或全项目PWF完成。
