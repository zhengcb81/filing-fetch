# ROOT 独立验收：DU6-FF-PORTABLE-EVIDENCE

审查 HEAD：`ff08a8e04f2ae146e42daf9b36710b3ef1f47d89`。作者树只读，无 Git/源码/安装写入；用户明确授权的 CodeGraph 索引已初始化，目标源码可用。

## 结论

可搬迁重放的核心实现范围正确：同一个 native oracle 的可选根透传，未修改 CaseSpec/SHA 判断；没有另建 oracle、证据库或许可链。已发现并在 ROOT 集成树修复一个 P2 共因。**源码已冻结，仍待 ROOT 串行集中回归后提交并线。**

## P2：原子输出没有完整落实文件所有权（已修）

原 `cli_main.py` 363附近使用固定 `output.partial` 并 `replace(output)`。两个独立行为 RED 真实复现：

1. 已存在的 `.partial` 哨兵被覆盖后移走；
2. audit 执行期间另一个写者新建的 output 被替换，命令仍 exit0。

`output-red.stdout.txt`：2 FAIL/3.45s。ROOT 允许在独立集成树修复共因后，改为同目录独占唯一临时文件，完整序列化关闭后用 `os.link` 原子且不覆盖地发布，finally 只清理本次文件；没有人工审批或第二实现。

`output-green.stdout.txt`：4 PASS/6.41s，包含原两反例、发布故障、序列化中断。`Ruff` 和 `git diff --check` 通过。实际本机 NTFS 正控通过；不支持硬链接的文件系统将明确 exit2，不降级覆盖，也不留半份 output。

## 保留证据端到端重放

独立复制既有真实41链报告和271文件到不同深度的中文/空格 Temp，调用真实 `run.py replay`；报告原字节 SHA 不变，271文件清单 SHA 全匹配。此次不重新采集41链，不触达供应商。

- 搬迁：38 PASS / 1 PARTIAL / 2 NOT_RUN，原5 findings完整保留，exit1、certified=false。
- 缺 override 根：exit2，无旧根回退。
- 一处 response 加1字节：新增原生 `invalid_bound_evidence` SHA finding，原失败保留。
- 丢失同一 response：新增原生缺件 finding。
- 历史失败样本：19 PASS / 21 FAIL / 1 PARTIAL，当前65 findings，原 recorded findings保留，不升级。
- ROOT输出所有权正负控在修复后也经实调用通过。

真实 CLI 的禁网 sitecustomize guard在子进程启动时装入；0外网/供应商/LLM/翻译/API费用。Temp与新增测试产物已删，sentinel、源码树 SHA、生产配置 metadata 前后相同。详细 argv/状态/结果见 `receipt.json` 和各重放 JSON。

## 尚未完成的大节点

首次独立248项集中测试命中审查 harness 的180秒总时限，没有最终计数；当时宿主存在多路测试。**不能据此宣称248通过，也不能判定产品业务deadline错误。** ROOT已要求暂缓大套件，待集中串行验收；原失败见 `concentrated-timeout.json`。作者的248 PASS收据仍是作者证据，未冒充本次结果。

待ROOT串行运行原248+ROOT新4项、正常提交、并线、远端CI和PWF更新。既有真实链三条 PARTIAL/NOT_RUN 继续在总计划具名保留，本卡未改预算/expected或重复跑求绿。

## 冻结交接

- ROOT集成树：`C:/Users/郑曾波/Projects/filing-fetch-du67-integration`。
- 仅新增改动：`tools/offline_contract_matrix/cli_main.py`，`tests/test_du67_replay_output_ownership.py`；精确SHA见 handoff.json。
- 不改作者树、主仓、ET、固定依赖或安装副本；本agent未Git提交。
